DB TV IPTV PRO

Import this project into Android Studio.
Click Build APK.

Features scaffolded:
- Login screen (Xtream / M3U)
- Home (Netflix style placeholder)
- Player (ExoPlayer ready)

You must connect your IPTV API (Xtream) in LoginActivity.
