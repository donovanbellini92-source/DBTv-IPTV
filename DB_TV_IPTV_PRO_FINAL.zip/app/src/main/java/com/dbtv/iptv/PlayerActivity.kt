package com.dbtv.iptv

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.*

class PlayerActivity : AppCompatActivity() {

 private lateinit var player: ExoPlayer

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)

  val view = com.google.android.exoplayer2.ui.PlayerView(this)
  setContentView(view)

  player = ExoPlayer.Builder(this).build()
  view.player = player

  val media = MediaItem.fromUri(Uri.parse("https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"))
  player.setMediaItem(media)
  player.prepare()
  player.play()
 }

 override fun onDestroy() {
  super.onDestroy()
  player.release()
 }
}