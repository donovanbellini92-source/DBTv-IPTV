package com.dbtv.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)

  val layout = LinearLayout(this)
  layout.orientation = LinearLayout.VERTICAL

  val title = TextView(this)
  title.text = "DB TV IPTV PRO"
  title.textSize = 24f

  val live = Button(this)
  live.text = "Live TV"

  live.setOnClickListener {
    startActivity(Intent(this, PlayerActivity::class.java))
  }

  layout.addView(title)
  layout.addView(live)

  setContentView(layout)
 }
}