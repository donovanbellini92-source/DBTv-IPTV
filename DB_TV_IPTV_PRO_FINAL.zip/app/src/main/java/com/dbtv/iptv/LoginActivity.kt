package com.dbtv.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)

  val layout = LinearLayout(this)
  layout.orientation = LinearLayout.VERTICAL

  val url = EditText(this)
  url.hint = "Serveur Xtream URL"

  val user = EditText(this)
  user.hint = "Username"

  val pass = EditText(this)
  pass.hint = "Password"

  val btn = Button(this)
  btn.text = "Connexion"

  btn.setOnClickListener {
    startActivity(Intent(this, HomeActivity::class.java))
  }

  layout.addView(url)
  layout.addView(user)
  layout.addView(pass)
  layout.addView(btn)

  setContentView(layout)
 }
}